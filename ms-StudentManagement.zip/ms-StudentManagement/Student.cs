namespace ms_StudentManagement
{
    public class Student
    {
        public string Name { get; set; }

      
    }
}